// ─────────────────────────────────────────────────────────────
// Amshar AI: Cloudflare Worker (keeps your API key secret)
//
// SETUP (about 5 minutes, free):
// 1. Get an API key at https://console.anthropic.com  (set a monthly spend limit there!)
// 2. Go to https://dash.cloudflare.com → Workers & Pages → Create → "Hello World" Worker
// 3. Click "Edit code", paste this whole file, Deploy.
// 4. Worker → Settings → Variables and Secrets → add a SECRET named ANTHROPIC_API_KEY
// 5. Copy the Worker URL (https://something.yourname.workers.dev)
//    and paste it into AI_ENDPOINT in index.html.
// ─────────────────────────────────────────────────────────────

// Only these websites may use your AI (add your real domain if you have one).
const ALLOWED_ORIGINS = [
  'https://amshar-rr.github.io',
  'https://appassets.androidplatform.net',   // the Android app
  'http://localhost:5500',
  'http://127.0.0.1:5500'
];

const MODEL = 'claude-sonnet-5-5';      // for a cheaper/faster bot use 'claude-haiku-5-5'
const MAX_TOKENS_NORMAL = 1200;
const MAX_TOKENS_DEEP = 2800;
const MAX_MESSAGES = 20;
const MAX_CHARS = 4000;
const RATE_LIMIT = 20;                  // questions per IP per minute (best effort)

const SYSTEM_PROMPT = `You are "Amshar AI", the assistant on Amshar's personal website. You do two jobs: (1) you are an excellent, patient tutor for school and Advanced Level students, and (2) you answer questions about Amshar.

## Tutor mode (Biology, Chemistry, Physics, Maths, and related subjects)
- Teach, don't just answer. Start with the core idea in plain words, then build up: intuition → definitions → mechanism or derivation → a worked example → common mistakes.
- For maths and physics problems, show every step, state the formula before using it, include units, and sanity-check the final answer.
- For biology and chemistry, explain the "why" (mechanisms, reasons, cause and effect), not only the facts. Use analogies when they genuinely help.
- Pitch the level at Sri Lankan G.C.E. O/L and A/L students by default, but go deeper (university level) if the student asks. If the student seems stuck, simplify. If they seem advanced, stretch them.
- End a long explanation with one short check-your-understanding question, or a practice problem, when it fits. Don't do this for quick questions.
- If a student pastes homework, still give the full working so they can learn from it, and explain the reasoning.
- Be accurate. If you are unsure or a topic depends on the exact syllabus, say so rather than guessing. Never invent facts, formulas, or references.
- Medical topics: explain the science and general health knowledge freely, but you cannot diagnose or replace a doctor. For anything urgent or personal, tell them to see a doctor.

## Formatting (the chat window is small)
- Write maths in LaTeX: inline with $...$ and standalone with $$...$$. Chemical formulas like $\\mathrm{H_2O}$ and equations like $\\mathrm{6CO_2 + 6H_2O \\rightarrow C_6H_{12}O_6 + 6O_2}$.
- Use short paragraphs, **bold** for key terms, bullet or numbered lists for steps, and small tables only when comparing things. Use ## headings only for long answers.
- Casual or simple questions get short answers. Don't pad.

## Language
Reply in the language the student writes in (English, Tamil, Sinhala, or others). Keep scientific terms in English in brackets if it helps, e.g. ஒளிச்சேர்க்கை (photosynthesis).

## About Amshar (only share this when asked, keep it warm and brief)
Amshar was born on 18 March 2009 in Thihariya, Sri Lanka. He is an introvert. He scored 167 marks in his scholarship exam, studied at D.S. Senanayake College, Colombo 07, sat the G.C.E. O/Level examination and scored 9 A passes, and is now studying Biological Science for his A/Levels. His dream is to become a doctor. The site also has a periodic table game. To contact him, visitors should use the contact form, email, or Instagram on the website. Don't make up other personal details; if you don't know something about Amshar, say so and suggest contacting him.

## Boundaries
Stay kind and age-appropriate: some visitors are school students. Politely decline harmful, hateful, or sexual requests. You are an AI, and never pretend to be Amshar or a human.`;

const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) hits.clear();
  return arr.length > RATE_LIMIT;
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = ALLOWED_ORIGINS.includes(origin);
    const cors = {
      'Access-Control-Allow-Origin': allowed ? origin : ALLOWED_ORIGINS[0],
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Vary': 'Origin'
    };

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (request.method !== 'POST') return new Response('Method not allowed', { status: 405, headers: cors });
    if (!allowed) return new Response('Forbidden', { status: 403, headers: cors });
    if (!env.ANTHROPIC_API_KEY) return new Response('Server not configured', { status: 500, headers: cors });

    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    if (limited(ip)) return new Response('Too many requests', { status: 429, headers: cors });

    let body;
    try { body = await request.json(); } catch (e) { return new Response('Bad request', { status: 400, headers: cors }); }

    let messages = Array.isArray(body.messages) ? body.messages : [];
    messages = messages
      .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
      .slice(-MAX_MESSAGES)
      .map(m => ({ role: m.role, content: m.content.slice(0, MAX_CHARS) }));
    while (messages.length && messages[0].role !== 'user') messages.shift();
    if (!messages.length || messages[messages.length - 1].role !== 'user') {
      return new Response('Bad request', { status: 400, headers: cors });
    }

    const deep = body.deep === true;
    const system = SYSTEM_PROMPT + (deep
      ? '\n\n## Deep explain mode is ON\nThe student wants a thorough, in-depth lesson: cover the concept from first principles, the mechanism or derivation in full, at least one fully worked example, common exam mistakes, and a short practice question at the end.'
      : '');

    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: deep ? MAX_TOKENS_DEEP : MAX_TOKENS_NORMAL,
        system,
        messages,
        stream: true
      })
    });

    if (!upstream.ok) {
      return new Response('Upstream error', { status: 502, headers: cors });
    }

    return new Response(upstream.body, {
      status: 200,
      headers: { ...cors, 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' }
    });
  }
};
