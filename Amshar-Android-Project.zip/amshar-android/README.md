# Amshar – Android app (armeabi-v7a)

Native WebView wrapper around your website. All pages (index, game, photo, control) are bundled
inside the APK and load instantly, even offline (fonts / EmailJS / AI chat still need internet).

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo (e.g. `amshar-android`) and upload **everything in this folder** (keep `.github`).
2. Open the **Actions** tab → **Build Amshar APK** → **Run workflow**.
3. After ~4 min open the finished run → **Artifacts → Amshar-APK** → download, unzip, install.

## IMPORTANT – AI chat inside the app
Deploy the included `worker.js` to Cloudflare (it now allows the origin
`https://appassets.androidplatform.net`). Without this the AI chat is blocked inside the app.

## Features
- Pages bundled offline; served from a secure https origin (WebViewAssetLoader)
- Pull-to-refresh, loading bar, hardware back = browser history, double-back to exit
- Instagram / WhatsApp / mail / phone / maps links open in the real apps
- Photo/file upload from the site (file chooser)
- File downloads via Android Download Manager (http/https links)
- Long-press app icon shortcuts: Home, Periodic Table, Photos
- Opens your github.io links inside the app
- Offline fallback page for remote links
- JavaScript bridge for your site: `AmsharApp.share(title,text)`, `.vibrate(ms)`, `.toast(msg)`,
  `.openExternal(url)`, `.version()`, `.isApp()` (check `window.AmsharApp` exists first)
- Dark theme splash, matches your site colours

## Updating the website
Replace files in `app/src/main/assets/www/`, bump `versionCode` in `app/build.gradle`, commit – rebuilds automatically.
